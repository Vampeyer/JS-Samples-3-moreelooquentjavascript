

//input array  

let arr = [2,5,6,3,8,9,"Jimmy cracked corn and I dont care"];

// square root calculation 

//let newArr = arr.map( => newArr + 1)
const squareRoots = arr.map(num => Math.sqrt(num));

console.log(squareRoots)









//input array  


// square root calculation 

//let newArr = arr.map( => newArr + 1)
const addArr = arr.map(num => num + num);

console.log(addArr)