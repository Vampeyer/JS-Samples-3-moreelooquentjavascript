

const numbers = [1, 4, 9, 16, 25];


let numbersMapped = numbers.map(index => Math.sqrt(index) )

console.log(numbersMapped)